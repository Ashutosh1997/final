package com.demo.usermanager.service;

import com.demo.usermanager.repository.UserRepository;
import com.demo.usermanager.repository.entity.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;

@Service
@AllArgsConstructor
public class UserDataLoaderService {
    private final UserRepository userRepository;

    @PostConstruct
    public void loadUserData() {
        try {
            ClassPathResource resource = new ClassPathResource("user.json");
            ObjectMapper objectMapper = new ObjectMapper();
            User[] users = objectMapper.readValue(resource.getFile(), User[].class);

            for (User user : users) {
                if (!userExists(user)) {
                    userRepository.save(user);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean userExists(User user) {
        return userRepository.existsByUsername(user.getUsername())
                || userRepository.existsByEmailId(user.getEmailId());
    }
}
