package com.demo.usermanager.controller;

import com.demo.usermanager.repository.UserRepository;
import com.demo.usermanager.repository.entity.User;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/users")
@AllArgsConstructor
public class AdminController {

    private final UserRepository userRepository;

    @GetMapping("/create")
    public String createUserForm(Model model) {
        model.addAttribute("user", new User());
        return "create-user";
    }

    @PostMapping("/create")
    public String createUser(@ModelAttribute("user") User user) {
        userRepository.save(user.toBuilder().isActive(true).role("USER").build());
        return "redirect:/admin/users/all";
    }

    @GetMapping("/{id}/update")
    public String updateUserForm(@PathVariable("id") String id, Model model) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id: " + id));
        model.addAttribute("user", user);
        return "update-user";
    }

    @PostMapping("/{id}/update")
    public String updateUser(@PathVariable("id") String id, @ModelAttribute("user") User updatedUser) {
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id: " + id));

        existingUser.setPhoneNumber(updatedUser.getPhoneNumber());
        existingUser.setUsername(updatedUser.getUsername());
        existingUser.setEmailId(updatedUser.getEmailId());
        existingUser.setIsActive(updatedUser.getIsActive());

        userRepository.save(existingUser);
        return "redirect:/admin/users/all";
    }

    @GetMapping("/{id}/delete")
    public String deleteUser(@PathVariable("id") String id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id: " + id));

        userRepository.delete(user);
        return "redirect:/admin/users/all"; // Redirect to the user list page
    }

    @GetMapping("/all")
    public String getUsers(Model model) {
        List<User> users = userRepository.findAll();
        model.addAttribute("users", users);
        return "user-list";
    }
}
